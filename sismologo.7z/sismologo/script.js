document.addEventListener("DOMContentLoaded", function() {
    const slides = document.querySelectorAll(".slide");
    let index = 0;
  
    function showSlide() {
      slides.forEach(slide => {
        slide.classList.remove("active");
      });
      slides[index].classList.add("active");
    }
  
    function nextSlide() {
      index++;
      if (index === slides.length) {
        index = 0;
      }
      showSlide();
    }
  
    setInterval(nextSlide, 5000); // Cambia de diapositiva cada 5 segundos
  });
  